<!DOCTYPE html>

<html lang="en">
  <head>

    <!-- Required meta tags -->
    <link rel="shortcut icon" type="image/jpeg" href="s.png">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no" />
  <meta name="keywords" content="red5fin website">
  <meta name="description" content="red5fin website.">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >

 <link href="../css/bootstrap.min.css "rel="stylesheet" type="text/css" >
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="http://code.jquery.com/jquery-3.3.1.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha.4/css/bootstrap.min.css">
    <script type="text/javascript" src="js/jquery-3.2.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
        
    <!-- new wa -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Bellefair|Dancing+Script|Inconsolata|Pacifico" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Bellefair|Dancing+Script|Inconsolata|Pacifico|Play" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Lobster|Righteous|Yellowtail" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Lobster|Pontano+Sans|Righteous|Yellowtail" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Lobster|Pontano+Sans|Quattrocento|Righteous|Yellowtail" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.rawgit.com/konpa/devicon/df6431e323547add1b4cf45992913f15286456d3/devicon.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection" />
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection" />
  <link href="css/main1.css" type="text/css" rel="stylesheet" />
  <script type="text/javascript" src="https://platform.linkedin.com/badges/js/profile.js" async defer></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Kumar+One" rel="stylesheet">
  <script src="js/typed.min.js"></script>
  <script src="js/main.js"></script>
    <style>
    
   #sm{text-align:center;margin-left:43%;}   
   #sh{text-align:center;color:black;font-size:20px;}
   #s{margin-left:10px;}
   .carousel-item img{
      height:100%;
      width:100%;
      
      }
.carousel-control-next-icon,.carousel-control-prev-icon{
      height:10%;
      width:10%;
}
.carousel-caption{
      background-color: black;
      color:white;
      width:100%;
      left:0;

}
.carousel-indicator{
      margin-bottom:20%;
}
.carousel-button{border-radius:50px;}
 @media(min-width: 768px) {
      .carousel-button{
            background-color:#f2ecb3; 
            color: #403a02;
            font-size: 20px;
      }
      .carousel-caption {
              background-color: transparent;
            color:#d7f5ec;
            width:100%;
            left:0;
            font-size: 28px;
      }
      
  }
  @media(max-width: 768px) {
      .carousel-caption{
            background-color: #5d4970;
            color:white;
            width:100%;
            left:0px;
            font-size: 19px;
            bottom:0;            
            margin:0px;
            padding:0%;
            padding-bottom:5%;
            line-height:100%;
            
      }
      .carousel-button{
      background-color:#FFF; 
      color:#e46226;
      font-size: 19px;
      line-height:50%;
      padding:3%;
      margin-bottom:8px;
      }
      .carousel-indicators
      {
            visibility:hidden;
      }
      .info-grids
      {
            background-size: cover; 
            background-repeat: no-repeat;
            width: 100%;
	      height: 100%;
      }
      .info-grids-para
      {
            font-size:16px; 
      }
      .info-grids-btn
      {
            background-color:#e46226; 
            color:#FFF; 
            font-size:16px; 
            font-weight:bold; 
            margin-bottom:1%;
      }
  } 
   
  .innovation-container .innovation-upper-container {
  position: relative;
  line-height: 1.6;
  letter-spacing: 0.05rem;
  font-size: 22pt;
  font-weight: 600;
  font-family: "Poppins", sans-serif;
  padding-top: 0em;
}

.innovation-container .innovation-upper-container::before {
  position: absolute;
  content: "";
  background: #006E96;
  height: 3px;
  width: 14%;
  left: 43%;
  bottom: 0;
}

.innovation-container .innovation-text-cont {
  font-family: "Poppins", sans-serif;
}

.innovation-container .innovation-text-cont .innovation-img {
  height: 60px;
  width: 60px;
}

.innovation-container .innovation-text-cont .innovation-col-head {
  color:  #105863;
  font-size: 18pt;
  font-weight: 700;
}
 
 .aasd{
     position: relative;
  -webkit-box-shadow: 0 8px 30px rgba(0, 0, 0, 0.9);
          box-shadow: 0 10px 20px rgba(0, 0, 0, 0.11);
  opacity: 1;
  }
.innovation-container .innovation-text-cont .innovation-text {
  font-size: 12pt;
  line-height: 1.67;
  color: #696969;
}


    </style>
     </head>
  <body>
  <?php include 'nav.php';?>
  <div class="cont">




<div id="myCarousel" class="carousel slide" data-ride="carousel"style="height:500px; padding:0px; margin:0px; top:0;">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
     
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" style="height:500px; padding:0px; margin:0px; top:0;">
    <div class="item active">
        <img src="3.jpg" alt="1" style="height:500px;width:100%; top:0;">
        <br/>
        
        
      </div>

      <div class="item">
      <img src="2.jpg" alt="2" style="width:100%;height:500px; top:0;">
        <br/>
        
      </div>
    
      

      <div class="item">
      <img src="1.jpg" alt="5" style="width:100%;height:500px; top:0;">
        <br/>
        
      </div>
    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>














  
  <div class="container" id="about">
    <div class="section">
      <div class="center">
        <h2 class="center">About Red5Fin Foundation</h2>
      </div>
      <hr class="heading">
      <p style="text-align:center;">
      We are a Social Enterprise that aspires to guide social entrepreneurs and fresh 
      graduates to a stage in where they can implement their innovative idea. We make
       sure their idea scrutinized by our Subject Matter Experts and fine-tuned for perfection.
        We support projects that have a positive social and environmental impact. 

We give a structure and framework by forming a legal,
 social enterprise entity. We make sure this entity has the perfect mix of talents
  and skills to achieve what they set to accomplish. 

Most importantly, we make sure they have skin in the game.
 We identify people at the grassroots level, so these ideas are the necessity of their community.
  We will be assisting them through Impact investors eventually to kick start their implementation.
      </p>
      
    </div>
  </div>
<!-- test -->
<div class="innovation-container " id="invv">
  <div class="container">
      <div class="row pt-5">
         <div class="col-12 text-center pb-5 ">
           <div class="innovation-upper-container " data-aos="fade-up">INVESTOR PORTAL
          </div>
      </div>
    </div>
 <div class="row">
       <div class="col-md-3 pb-3">
        <div class="innovation-text-cont justify-content-center align-item-center ">
<div class="card">
<img class="card-img-top" height="200px" src="i0.png" alt="RANK">
<div class="card-body">
<div class=" text-center innovation-col-head mb-2" data-aos="fade-up">Project Ranking
</div>
<div class="innovation-text text-justify mt-2" data-aos="fade-up">
Ranking based on ESG impact, ROI, Social Enterprise Directors credibility
</div>

</div>
</div>
</div>
</div>
<div class="col-md-3 pb-3">
<div class="innovation-text-cont justify-content-center align-item-center ">
<div class="card">
<img class="card-img-top" height="200px" src="i1.svg" alt="Fund">
<div class="card-body">
<div class=" text-center innovation-col-head mb-2" data-aos="fade-up">Funds Schedule
</div>
<div class="innovation-text text-justify mt-2" data-aos="fade-up"> 
Milestone based funding schedule to increase the chances of success and give trust to investor

</div>

</div>
</div>
</div>
</div>
<div class="col-md-3 pb-3">
<div class="innovation-text-cont justify-content-center align-item-center ">
<div class="card">
<img class="card-img-top" height="200px" src="i4.svg" alt="report">
<div class="card-body">
<div class=" text-center innovation-col-head mb-2" data-aos="fade-up">Project Status Report
</div>
<div class="innovation-text text-justify mt-2" data-aos="fade-up">
Granular project status report with up to date photos,expense report, Second Party Audits
</div>

</div>
</div>
</div>
</div>
<div class="col-md-3 pb-5" >
<div class="innovation-text-cont justify-content-center align-item-center ">
<div class="card">
<img class="card-img-top" height="200px" src="i3.svg" alt="Feeding Kids">
<div class="card-body"> 
<div class=" text-center innovation-col-head mb-2" data-aos="fade-up">Investment Return Support
</div>
<div class="innovation-text text-justify mt-2" data-aos="fade-up">
Ensures the investment return is protected throughout the cycle of the tenure

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<!--Section: Contact v.2-->
<div class="container" id="join">
    <div class="section">
      <div class="center">
        <h2 class="center">Get Involved</h2>
      </div>
      <hr class="heading">
      <a class="btn btn-primary" href="https://tinyurl.com/y98f78o9" role="button">Join as a
       Core Member</a>
      <button type="button" class="btn btn-primary" href="">Join as a Volunteer</button>
      <p style="text-align:center;">
      
      </p>
      
    </div>
  </div>



<!-- Footer -->
<footer id="cont" class="page-footer font-small unique-color-dark"style="background-color: #e3e2e1;">

  <div style="background-color:#125082;color:white;">
    <div class="container">

      <!-- Grid row-->
      <div class="row py-4 d-flex align-items-center">

        <!-- Grid column -->
        <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
          <h6 class="mb-0">Get connected with us on social networks!</h6>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-6 col-lg-7 text-center text-md-right">

          <!-- Facebook -->
          <a class="fb-ic" style="padding-right:20px">
          <i id="social-tw"
                class="fa fa-facebook fa-2x social"></i>
          </a>
          
          
          <!--Linkedin -->
          <a class="li-ic">
          <i id="social-tw"
                class="fa fa-linkedin-square fa-2x social"></i>
          </a>
         

        </div>
        <!-- Grid column -->

      </div>
      <!-- Grid row-->

    </div>
  </div>

  <!-- Footer Links -->
  <div class="container text-center text-md-left mt-5">

    <!-- Grid row -->
    <div class="row mt-3">

      <!-- Grid column -->
      <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">

        <!-- Content -->
        <h6 class="text-uppercase font-weight-bold">RED5FIN Foundation</h6>
        <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p>Transform the world by empowering fresh graduates and social
entrepreneurs to implement their sustainable project and make them
leaders in their community</p>

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-5 col-lg-6 col-xl-4 mx-auto mb-4">

        <!-- Links -->
        <h6 class="text-uppercase font-weight-bold">Mission</h6>
        <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 80px;">
        <div class="embed-responsive embed-responsive-16by9 mb-4">
          <iframe class="embed-responsive-item" src="RED5FINi.mp4" controls
            ></iframe>
        </div>

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
     
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

        <!-- Links -->
        <h6 class="text-uppercase font-weight-bold">Contact</h6>
        <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p>
          <i class="fa fa-home mr-3"></i>22-Upper East Coast Road,Singapore-456374 </p>
         <p> <i class="fa fa-envelope mr-3"></i> vtpaulson@gmail.com</p>
        <p>
          <i class="fa fa-phone mr-3"></i> +65 94560420</p>
        <p>
          <i class="fa fa-print mr-3"></i> +65 94560420 </p>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

  <!-- Copyright -->
  
  <!-- Copyright -->

</footer>
<!-- Footer -->


<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    
    <script src="js/consolemsg.js"></script>
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>



     


<script
  src="https://code.jquery.com/jquery-1.7.2.min.js"
  integrity="sha256-R7aNzoy2gFrVs+pNJ6+SokH04ppcEqJ0yFLkNGoFALQ="
 crossorigin="anonymous">
</script>



  </body>
</html>




